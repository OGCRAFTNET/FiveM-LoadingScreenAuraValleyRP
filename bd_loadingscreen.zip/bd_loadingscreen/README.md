# bd_loadingscreen
This script was made for you by **BebikDEV**. We will be glad for any support on our **discord: https://discord.gg/4VwXy4aDBd**

![logoyoutubepozadi5](https://github.com/Bebicek/bd_loadingscreen/assets/133703817/b8686a19-f627-4b6c-8667-39ec6896eaeb)

**Voluntary support: https://ko-fi.com/bebikdev**

# How to Install
- Download file and drop in your “**resources**” folder
- Add to your **server.cfg** file:  ***ensure bd_loadingscreen***
- Install done. Have Fun !!

# Controls
- **Space** (Play/Stop music)
- **ArrowUp-Key** (Volume up)
- **ArrowDown-Key** (Volume down)
- **ArrowLeft-Key/ArrowRight-Key** (Changing music)

# Screenshot
![image](https://github.com/Bebicek/bd_loadingscreen/assets/133703817/c7ce2d81-b03f-44e2-9906-8388dfd00c23)


# Video
https://www.youtube.com/watch?v=OgyI1AqS8S4

Credits for video: **GamingCZE11**
